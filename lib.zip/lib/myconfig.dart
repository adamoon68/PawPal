class MyConfig {
  static const String baseUrl= "http://10.29.208.159";
}